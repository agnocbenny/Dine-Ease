from django.urls import path

from.import views

urlpatterns = [
    path('alog',views.alog,name="alog"), 
]
