from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static 
from.import views

urlpatterns = [
    path('log',views.log,name="log"), 
    path('ureg',views.ureg,name="ureg"),  
    path('uhome',views.uhome,name="uhome"),
    path('uprofile',views.uprofile,name="uprofile"),


]
