from django.db import models

# Create your models here.
class user_DB(models.Model):
    Username=models.CharField(max_length=25)
    Email=models.EmailField(max_length=45)
    password=models.CharField(max_length=10)
    Profile=models.ImageField(upload_to='user')

def _str_(self):
    return self.Username