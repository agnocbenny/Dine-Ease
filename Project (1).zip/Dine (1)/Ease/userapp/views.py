from django.shortcuts import render,redirect
from.models import *
from userapp.models import *
from django.contrib import messages


# # Create your views here.
# def reg(request):
#     return render(request,')
def log(request):
if request.method=="POST":
        try:
            usename=request.POST.get("username")
            password=request.POST.get("pwd")
            log=user_DB.objects.get(Username=usename,password=password)
            request.session['Username']=log.Username
            request.session['id']=log.id
            
            return redirect('uhome')
        except user_DB.DoesNotExist as e:
                messages.info(request,'Invalid User')
    return render(request,'user/login.html')


def ureg(request):
    if request.method=="POST":
        username=request.POST.get("username") 
        email=request.POST.get("email")
        pro=request.FILES.get("profile")
        p1=request.POST.get("password")
        p2=request.POST.get("confirmpassword")
        if p1==p2:
            if user_DB.objects.filter(Username=username).exists():
                messages.info(request,'Username Already Exist')
            else:
                userdata=user_DB(Username=username,Email=email,password=p1,Profile=pro)
                userdata.save()
                return redirect("log")
        else:
            messages.info(request,'password not match')
    return render(request,'user/ureg.html')


def uhome(request):
    return render(request,'user/uhome.html')

def uprofile(request):
    userid=request.session['id']
    userpro=user_DB.objects.get(id=userid)
    return render(request,'user/uprofile.html',{'upr':userpro})

def ueditprofile(request):
    userdata=user_DB.objects.get(id=request.session['id'])
    if request.method=="POST":
        if len(request.FILES)!=0:
            if len(userdata.img)>0:
                os.remove(userdata.img.path)
            userdata.profile=request.FILES['img']
        userdata.username=request.POST['name']
        userdata.email=request.POST['email']
        userdata.password=request.POST['password']
        userdata.save()
        return redirect('uprofile')
    return render(request,"user/ureg.html",{"upr":userpro})