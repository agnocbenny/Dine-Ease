from django.shortcuts import render,redirect
from.models import *
from userapp.models import *
from django.contrib import messages

# Create your views here.
def rlog(request):
    if request.method=="POST":
        try:
            usename=request.POST.get("username")
            password=request.POST.get("pwd")
            log=user_DB.objects.get(Username=usename,password=password)
            request.session['Username']=log.Username
            request.session['id']=log.id
            
            return redirect('rhome')
        except user_DB.DoesNotExist as e:
                messages.info(request,'Invalid User')
    return render(request,'restaurant/rlog.html')
def rreg(request):
    if request.method=="POST":
        Username=request.POST.get("username")
        contact=request.POST.get("contact")
        place=request.POST.get("place")
        email=request.POST.get("email")
        exp=request.POST.get("experience")
        bname=request.POST.get("bname")
        img=request.FILES.get("img")
        p1=request.POST.get("password")
        p2=request.POST.get("confirmpassword")
        if p1==p2:
            if restaurant_DB.objects.filter(Username=username).exists():
                messages.info(request,'Username Already Exists')
            else:
                userdata=restaurant_DB(Username=username,Contact=contact,Place=place,Image=img,Email=email,Businessname=bname,Experience=exp,Password=p1)
                userdata.save()
                return redirect("rlog")
        else:
            messages.info(request,'password not match')
    return render(request,'restaurant/rreg.html')
                                                                                                                                                                                                                                                                                                                               
def rhome(request):
    return render(request,'restaurant/rhome.html')