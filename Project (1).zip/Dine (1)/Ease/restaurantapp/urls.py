from django.urls import path

from.import views

urlpatterns = [
    path('rlog',views.rlog,name="rlog"),
    path('rreg',views.rreg,name="rreg"),
    path('rhome',views.rhome,name="rhome"),
  


]
