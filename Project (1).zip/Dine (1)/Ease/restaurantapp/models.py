from django.db import models

# Create your models here.
class restaurant_DB(models.Model):
    Username=models.CharField(max_length=25)
    Contact=models.CharField(max_length=45)
    Email=models.EmailField(max_length=50)
    Businessname=models.CharField(max_length=25)
    Place=models.CharField(max_length=50)
    Password=models.CharField(max_length=10)
    Image=models.ImageField(upload_to='restaurant')
    Experience=models.IntegerField()
    
def _str_(self):
    return self.Username
    